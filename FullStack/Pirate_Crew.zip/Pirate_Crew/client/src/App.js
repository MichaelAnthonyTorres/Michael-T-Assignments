import React from 'react';
import Main from '../src/views/Main';
import { Router } from '@reach/router'
import PirateForm from './components/AddPirate';
import DisplayPirate from './components/OnePirate';

function App(){
  return (
    <div className="App">
      <Router>
        <Main path="/pirates" />
        <PirateForm path="/pirates/new"/>
        <Pirate path="/pirates/:_id"/>
      </Router>

    </div>
  );
}

export default App;

