import axios from "axios";
import React, { useState, useEffect } from "react";

const Pirate = (props) =>{
    const { pirateId } = props;
    const [pirateInfo, setPirateInfo] = useState();

    useEffect(() =>{
        axios
        .get(`http://localhost:8000/api/pirate/${pirateId}`)
        .then((onePirate)=>{
            console.log(onePirate);
            setPirateInfo(onePirate.data.onePirate)
        })
        .catch((err)=> console.log(err))
    })

    return (
        <>
        {pirateInfo ? (
        <div>
            <h1>{pirateInfo.name}</h1>
            <div>
                <p>{pirateInfo.position}</p>
                <p>{pirateInfo.treasure}</p>
                <p>{pirateInfo.hasPegLeg}</p>
                <p>{pirateInfo.hasEyePatch}</p>
                <p>{pirateInfo.hasHooKHand}</p>
            </div>     
        </div>
        ):null}
        </>
    )
}

export default Pirate