import axios from "axios";
import React, { useState } from "react";

const crewPosition = [
    "Captain",
    "First Mate",
    "Cook",
    "Musician",
    "Doctor",
    "Navigator",
    "Shipwright",
    "Sniper",
];

const PirateForm = (props) => {
    const [name, setName] = useState("");
    const [image, setImage] = useState("");
    const [treasure, setTreasure] = useState("");
    const [catchPhrase, setCatchPhrase] = useState("");
    const [position, setPosition] = useState("Captain");
    const [hasPegLeg, setHasPegLeg] = useState(true);
    const [hasEyePatch, setHasEyePatch] = useState(true);
    const [hasHookHand, setHasHookHand] = useState(true);
    const {formSubmitted, setFormSubmitted} = props;

    const handleFormSubmit = (e) => {
        e.preventDefault();
        const newPirateInfo = {
            name,
            image,
            treasure,
            catchPhrase,
            position,
            hasPegLeg,
            hasEyePatch,
            hasHookHand,
        };
        console.log("pirate info", newPirateInfo);
        axios
            .post("http://localhost:8000/api/pirate", newPirateInfo)
            .then((newPirate) => {
                setName("");
                setImage("");
                setTreasure("");
                setCatchPhrase("");
                setPosition("Captain");
                setHasPegLeg(true);
                setHasEyePatch(true);
                setHasHookHand(true);
                setFormSubmitted(!formSubmitted)
            })
            .catch((err)=> console.log(err))
    }
    return (
    <>    
        <h1>Pirate Form</h1>
        <form onSubmit = {handleFormSubmit}>
            <div className="firstHalf">
                <div>
                    <label htmlFor="name">Pirate Name</label>
                    <input 
                        type="text"
                        name = "name"
                        id = "name"
                        onChange = {(e) => setName(e.target.value)}
                        value={name}
                    />
                </div>
                <div>
                    <label htmlFor="image">Picture</label>
                    <input 
                        type="text"
                        name = "image"
                        id = "image"
                        onChange = {(e) => setImage(e.target.value)}
                        value = {image}
                    />
                </div>
                <div>
                    <label htmlFor="treasure">Treasure</label>
                    <input
                    type = "number"
                    name = "treasure"
                    min = "0"
                    max = "1000"
                    step = "1"
                    id = "treasure"
                    onChange = {(e) => setTreasure(e.target.value)}
                    value = {treasure}
                    />
                </div>
                <div>
                    <label htmlFor="catchPhrase">Catch Phrase</label>
                    <input 
                        type="text"
                        name = "catchPhrase"
                        id = "catchPhrase"
                        onChange = {(e) => setCatchPhrase(e.target.value)}
                        value={catchPhrase}
                    />
                </div>
            </div>
            <div className="secondHalf">
                <div>
                    <label htmlFor="position">Crew Position</label>
                    <select 
                        name = "position"
                        value = {position}
                        onChange = {(e) => setPosition(e.target.value)}
                        id = "position"
                    >
                        {crewPosition.map((crew, index) =>(
                            <option key={index} value={crew}>
                                {crew}
                            </option>
                        ))} 
                    </select>
                </div>
                <div>
                    <label htmlFor="hasPegLeg">Peg Leg</label>
                    <input 
                        type="checkbox"
                        name = "hasPegLeg"
                        id = "hasPegLeg"
                        onChange = {(e) => setHasPegLeg(!hasPegLeg)}
                        readOnly
                        checked={hasPegLeg}
                    />
                </div>
                <div>
                    <label htmlFor="hasEyePatch">Eye Patch</label>
                    <input 
                        type="checkbox"
                        name = "hasEyePatch"
                        id = "hasEyePatch"
                        onChange = {(e) => setHasEyePatch(!hasEyePatch)}
                        readOnly
                        checked={hasEyePatch}
                    />
                </div>
                <div>
                    <label htmlFor="hasHookHand">Hook Hands</label>
                    <input 
                        type="checkbox"
                        name = "hasHookHand"
                        id = "hasHookHand"
                        onChange = {(e) => setHasHookHand(!hasHookHand)}
                        readOnly
                        checked={hasHookHand}
                    />
                </div>
            </div>
            <button>Add Pirate</button>
        </form>
    </>
    )
}

export default PirateForm
