import React, { useEffect, useState } from "react";
import axios from "axios"

const DisplayPirates = ( props ) => {
    const { formSubmitted, setFormSubmitted } = props
    const [pirates, setPirates] = useState([]);
    useEffect(() => {
        axios
        .get("http://localhost:8000/api/pirate")
        .then((allPirates) => {
            setPirates(allPirates.data.allPirates);
            console.log(allPirates)
        })
        .catch((err) => console.log(err))
    }, [formSubmitted]);

    const deletePirate =(id)=> {
        axios
        .delete(`http://localhost:8000/api/pirate/${id}`)
        .then(response =>{
            console.log("deletion successful");
            setFormSubmitted(!formSubmitted);
        })
        .catch((err) => console.log(err))
    };

    return  (
        <div>
            <h1>Ahoy Thee Maytee</h1>
            <hr/>
            {pirates.length > 0 &&
            pirates.map((pirate, index) =>(
                <div key = {index} >
                    <img src={pirate.image} alt=""/>
                    <p>{pirate.name}</p>
                    <button onClick={()=> deletePirate(pirate._id)}>Walk The Plank</button>
                </div>
            ))}
        </div>
    )

}

export default DisplayPirates