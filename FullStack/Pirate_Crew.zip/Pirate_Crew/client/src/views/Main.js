import React, { useEffect, useState } from 'react'
import PirateForm from '../components/AddPirate';
import DisplayPirates from '../components/PirateDisplay';

const Main = () =>{
    const [formSubmitted, setFormSubmitted] = useState(false)
   return (
       <div>
           <DisplayPirates
                formSubmitted= {formSubmitted}
                setFormSubmitted = {setFormSubmitted} 
            />

       </div>
   )
}

export default Main;