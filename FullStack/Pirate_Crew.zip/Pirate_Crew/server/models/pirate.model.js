const mongoose = require('mongoose');

const PirateSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Arrrr, wheres ye name'],
        minlength: [5, 'If ye name was a plank ye would fall. Make it longer!!!']
    },

    image: {
        type: String,
        required: [true, 'Must show thee face'],
    },

    treasure: {
        type: Number,
        // requried: [true, 'We dont like Pirates with no booty"']
    },

    catchPhrase: {
        type: String,
        required: [true, "Ye must say somethng!!!! "],
        minLength: [5, "Don't be a lazy scalliwag. Add more characters"]
    },

    position: {
        type: String,
        required: [true, "Pick a position"],
        enum: ["Captain", "First Mate", "Cook", "Musician", "Navigator", "Doctor", "Sniper", "Shipwright"]
    },

    hasPegLeg: {
        type: Boolean,
        default: false
    },
    
    hasEyePatch: {
        type: Boolean,
        default: false
    },
    
    hasHookHand: {
        type: Boolean,
        default: false
    },
})

module.exports = mongoose.model('Pirate', PirateSchema)