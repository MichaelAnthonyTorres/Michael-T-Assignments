const Pirate = require('../models/pirate.model')

const createPirate = (req, res) => {
    Pirate.create({
        name: req.body.name,
        image: req.body.image,
        treasure: req.body.treasure,
        catchPhrase: req.body.catchPhrase,
        position: req.body.position,
        hasPegLeg: req.body.HasPegLeg,
        hasEyePatch: req.body.hasEyePatch,
        hasHookHand: req.body.hasHookHand,
    }).then((addPirate)=> res.json({addPirate}))
    .catch((err) => res.status(400).json({error: err}))
}

const getAllPirates = (req, res) => {
    Pirate.find()
    .then((allPirates)=> res.json({allPirates}))
    .catch((err) => res.status(400).json({error: err}))
}

const getOnePirate = (req, res) => {
    Pirate.findOne({_id: req.params.pirateId})
    .then((onePirate)=> res.json({onePirate}))
    .catch((err) => res.status(400).json({error: err}))
}

const updatePirate = (req, res) => {
    Pirate.findOneAndUpdate(
        {_id: req.params.pirateId},
        req.body,
        {new: true,
        runValidators: true
    })
    .then((currentPirate)=> res.json({currentPirate}))
    .catch((err) => res.status(400).json({error: err}))
}

const deletePirate = (req, res) => {
    Pirate.deleteOne({_id: req.params.pirateId})
    .then((removePirate)=> res.status(200).send('Deleted'))
    .catch((err) => res.status(400).json({error: err}))
}



module.exports = {
    createPirate,
    getOnePirate,
    getAllPirates,
    updatePirate,
    deletePirate,
}
