const PirateController = require('../controllers/pirate.controller');

module.exports = (app) => {
    app.get("/api/pirate", PirateController.getAllPirates);
    app.post("/api/pirate", PirateController.createPirate);
    app.get("/api/pirate/:pirateId", PirateController.getOnePirate);
    app.put("/api/pirate/:pirateId", PirateController.updatePirate);
    app.delete("/api/pirate/:pirateId", PirateController.deletePirate);
}